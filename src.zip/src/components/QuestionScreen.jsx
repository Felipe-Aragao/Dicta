import { useState, useEffect } from "react";
import {
  SpeakerHigh,
  Microphone,
  StopCircle,
  ArrowLeft,
  ArrowRight,
  Check,
  ArrowCounterClockwise,
} from "@phosphor-icons/react";
import { useSpeech } from "../hooks/useSpeech";

const LETTERS = ["A", "B", "C", "D", "E"];

// ─── Alternativas ────────────────────────────────────────────────
function Alternatives({ options, selectedAlt, onSelect }) {
  return (
    <div className="alts" role="radiogroup" aria-label="Alternativas de resposta">
      {options.map((opt, i) => (
        <button
          key={i}
          className={`alt-btn${selectedAlt === i ? " selected" : ""}`}
          role="radio"
          aria-checked={selectedAlt === i}
          onClick={() => onSelect(i)}
          aria-label={`Alternativa ${LETTERS[i]}: ${opt}`}
        >
          <span className="alt-letter" aria-hidden="true">{LETTERS[i]}</span>
          <span>{opt}</span>
        </button>
      ))}
    </div>
  );
}

// ─── Painel de Voz ───────────────────────────────────────────────
function VoicePanel({ recording, transcription, onToggle }) {
  return (
    <div className="voice-panel">
      {recording && (
        <div className="waveform" aria-hidden="true">
          {[...Array(7)].map((_, i) => (
            <div key={i} className="wave-bar" />
          ))}
        </div>
      )}

      <button
        className={`mic-btn${recording ? " rec" : ""}`}
        onClick={onToggle}
        aria-label={recording ? "Parar gravação" : "Iniciar gravação de voz"}
        aria-pressed={recording}
      >
        {recording
          ? <StopCircle size={28} weight="regular" />
          : <Microphone size={28} weight="regular" />}
      </button>

      <p
        className={`voice-label${recording ? " rec" : ""}`}
        role="status"
        aria-live="polite"
      >
        {recording
          ? "Gravando — clique para parar"
          : transcription
          ? "Gravação concluída"
          : "Clique no microfone para responder"}
      </p>
    </div>
  );
}

// ─── Tela principal ──────────────────────────────────────────────
export function QuestionScreen({ questions, onComplete }) {
  const [idx, setIdx]                     = useState(0);
  const [recording, setRecording]         = useState(false);
  const [transcription, setTranscription] = useState("");
  const [selectedAlt, setSelectedAlt]     = useState(null);
  const [answers, setAnswers]             = useState([]);

  const { speak, startRec, stopRec } = useSpeech();

  const q          = questions[idx];
  const isLast     = idx === questions.length - 1;
  const isMultiple = q.type === "multiple";
  const canNext    = isMultiple ? selectedAlt !== null : transcription.length > 0;
  const pct        = Math.round(((idx + 1) / questions.length) * 100);

  useEffect(() => { speak(q.text); }, [idx]);

  const toggleRec = () => {
    if (recording) { stopRec(); setRecording(false); return; }
    const ok = startRec(
      (text) => setTranscription(text),
      ()     => setRecording(false)
    );
    if (ok) setRecording(true);
  };

  const handleSelectAlt = (i) => {
    setSelectedAlt(i);
    speak(q.options[i]);
  };

  const saveAndNext = () => {
    const ans = isMultiple
      ? { qIdx: idx, type: "multiple", text: q.options[selectedAlt], alt: selectedAlt }
      : { qIdx: idx, type: "open",     text: transcription };

    const nextAnswers = [...answers, ans];
    setAnswers(nextAnswers);

    if (isLast) { onComplete(nextAnswers); return; }

    setIdx((i) => i + 1);
    setTranscription("");
    setSelectedAlt(null);
    setRecording(false);
  };

  const goBack = () => {
    if (idx <= 0) return;
    setIdx((i) => i - 1);
    setTranscription("");
    setSelectedAlt(null);
    setRecording(false);
  };

  return (
    <>
      {/* Barra de progresso */}
      <div className="prog-bar-wrap">
        <div className="prog-bar-inner">
          <div className="prog-meta">
            <span className="prog-label">Questão {idx + 1} de {questions.length}</span>
            <span className="prog-pct">{pct}%</span>
          </div>
          <div
            className="prog-track"
            role="progressbar"
            aria-valuenow={pct}
            aria-valuemin={0}
            aria-valuemax={100}
          >
            <div className="prog-fill" style={{ width: `${pct}%` }} />
          </div>
        </div>
      </div>

      <div className="page page-anim">
        <div className="page-narrow" style={{ maxWidth: "var(--shell-max)" }}>

          {/* Layout dividido: questão à esquerda, resposta à direita */}
          <div className="question-layout">

            {/* Painel da questão */}
            <div className="question-panel">
              <div className="card" style={{ height: "100%" }}>
                <div className="q-meta">
                  <span className="q-meta-badge">
                    {isMultiple ? "Múltipla escolha" : "Dissertativa"}
                  </span>
                </div>
                <p className="q-text">{q.text}</p>

                <div className="action-row" style={{ marginTop: 24 }}>
                  <button
                    className="btn btn-outline btn-sm"
                    onClick={() => speak(q.text)}
                    aria-label="Ouvir questão em voz alta"
                  >
                    <SpeakerHigh size={15} weight="regular" />
                    Ouvir questão
                  </button>
                  {isMultiple && selectedAlt !== null && (
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => speak(q.options[selectedAlt])}
                      aria-label="Ouvir alternativa selecionada"
                    >
                      <SpeakerHigh size={15} weight="regular" />
                      Ouvir alternativa
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Painel de resposta */}
            <div className="answer-panel">
              <div className="card" style={{ height: "100%" }}>
                <p style={{ fontSize: "0.78rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: ".07em", color: "var(--text-3)", marginBottom: 16 }}>
                  Sua resposta
                </p>

                {isMultiple ? (
                  <Alternatives
                    options={q.options}
                    selectedAlt={selectedAlt}
                    onSelect={handleSelectAlt}
                  />
                ) : (
                  <>
                    <VoicePanel
                      recording={recording}
                      transcription={transcription}
                      onToggle={toggleRec}
                    />
                    {transcription && (
                      <div className="trans-box">
                        <span className="trans-label">Transcrição</span>
                        {transcription}
                      </div>
                    )}
                    {transcription && (
                      <button
                        className="btn btn-ghost btn-sm"
                        style={{ marginTop: 10 }}
                        onClick={() => { setTranscription(""); setRecording(false); }}
                        aria-label="Refazer gravação"
                      >
                        <ArrowCounterClockwise size={14} weight="regular" />
                        Refazer
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Navegação */}
          <div className="nav-row">
            <button
              className="btn btn-outline"
              disabled={idx === 0}
              onClick={goBack}
              aria-label="Questão anterior"
            >
              <ArrowLeft size={16} weight="regular" />
              Anterior
            </button>
            <button
              className="btn btn-primary"
              disabled={!canNext}
              onClick={saveAndNext}
              aria-label={isLast ? "Finalizar questionário" : "Próxima questão"}
            >
              {isLast ? (
                <>
                  <Check size={16} weight="bold" />
                  Finalizar
                </>
              ) : (
                <>
                  Próxima
                  <ArrowRight size={16} weight="regular" />
                </>
              )}
            </button>
          </div>

        </div>
      </div>
    </>
  );
}

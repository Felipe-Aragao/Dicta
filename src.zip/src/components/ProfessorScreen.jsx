import { useState } from "react";
import { Plus, Users, FilePdf, ArrowRight } from "@phosphor-icons/react";

const MOCK_QUESTIONARIOS = [
  { id: 1, nome: "Atividade 8", status: "Ativo", criadoEm: "12/07/2026", alunos: 4 },
  { id: 2, nome: "Atividade 7", status: "Ativo", criadoEm: "19/05/2026", alunos: 8 },
  { id: 3, nome: "Prova 8",     status: "Ativo", criadoEm: "04/06/2026", alunos: 7 },
];

function NovaAtividadeModal({ onClose, onCreate }) {
  const [nome, setNome] = useState("");

  const handleSubmit = () => {
    if (!nome.trim()) return;
    onCreate(nome.trim());
    onClose();
  };

  return (
    <div
      className="modal-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-h"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="modal-card">
        <h2 className="modal-title" id="modal-h">Nova Atividade</h2>

        <label className="field-label" htmlFor="nome-input">
          Nome da atividade
        </label>
        <input
          id="nome-input"
          className="text-input"
          type="text"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") handleSubmit(); }}
          placeholder="Ex: Atividade 9, Prova Final..."
          autoFocus
        />

        <div className="modal-actions">
          <button
            className="btn btn-outline"
            onClick={onClose}
            aria-label="Cancelar"
          >
            Cancelar
          </button>
          <button
            className="btn btn-primary"
            disabled={!nome.trim()}
            onClick={handleSubmit}
            aria-label="Criar atividade"
          >
            Criar atividade
          </button>
        </div>
      </div>
    </div>
  );
}

export function ProfessorScreen() {
  const [questionarios, setQuestionarios] = useState(MOCK_QUESTIONARIOS);
  const [showModal, setShowModal]         = useState(false);

  const handleCreate = (nome) => {
    setQuestionarios((prev) => [
      {
        id: Date.now(),
        nome,
        status: "Ativo",
        criadoEm: new Date().toLocaleDateString("pt-BR"),
        alunos: 0,
      },
      ...prev,
    ]);
  };

  return (
    <>
      <div className="page page-anim">
        <div className="page-wide">

          {/* Header */}
          <div className="section-header">
            <div>
              <h2 className="section-title">Gerar Questionários</h2>
              <p className="section-sub">{questionarios.length} atividade{questionarios.length !== 1 ? "s" : ""} criada{questionarios.length !== 1 ? "s" : ""}</p>
            </div>
            <button
              className="btn btn-primary"
              onClick={() => setShowModal(true)}
              aria-label="Criar nova atividade"
            >
              <Plus size={16} weight="bold" />
              Nova Atividade
            </button>
          </div>

          {/* Tabela */}
          <div className="card" style={{ padding: 0, overflow: "hidden" }}>
            <table
              className="data-table"
              role="table"
              aria-label="Lista de questionários"
            >
              <thead>
                <tr>
                  <th scope="col">Questionário</th>
                  <th scope="col">Status</th>
                  <th scope="col">Criado em</th>
                  <th scope="col">Alunos</th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                {questionarios.map((q) => (
                  <tr
                    key={q.id}
                    className="data-row"
                    tabIndex={0}
                    aria-label={`${q.nome}, ${q.status}, ${q.criadoEm}`}
                    onClick={() => alert(`Abrindo: ${q.nome}`)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ")
                        alert(`Abrindo: ${q.nome}`);
                    }}
                  >
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <FilePdf size={16} color="var(--text-3)" weight="regular" />
                        {q.nome}
                      </div>
                    </td>
                    <td>
                      <span className="badge badge-green">{q.status}</span>
                    </td>
                    <td>{q.criadoEm}</td>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--text-3)", fontSize: "0.85rem" }}>
                        <Users size={14} weight="regular" />
                        {q.alunos} aluno{q.alunos !== 1 ? "s" : ""}
                      </div>
                    </td>
                    <td style={{ textAlign: "right" }}>
                      <ArrowRight size={16} color="var(--text-3)" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {questionarios.length === 0 && (
              <div
                style={{ padding: "64px 32px", textAlign: "center", color: "var(--text-3)", fontSize: "0.9rem" }}
                role="status"
              >
                Nenhuma atividade criada ainda.
              </div>
            )}
          </div>

        </div>
      </div>

      {showModal && (
        <NovaAtividadeModal
          onClose={() => setShowModal(false)}
          onCreate={handleCreate}
        />
      )}
    </>
  );
}

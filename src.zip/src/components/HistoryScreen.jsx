import { DownloadSimple, ArrowRight, ClockCounterClockwise } from "@phosphor-icons/react";
import { HISTORY_DATA } from "../data/demoData";

export function HistoryScreen() {
  return (
    <div className="page page-anim">
      <div className="page-wide">

        <div className="section-header">
          <div>
            <h2 className="section-title">Histórico</h2>
            <p className="section-sub">Seus questionários respondidos</p>
          </div>
          <button
            className="btn btn-outline"
            onClick={() => alert("Exportar PDF — integração futura")}
            aria-label="Exportar histórico como PDF"
          >
            <DownloadSimple size={16} weight="regular" />
            Exportar PDF
          </button>
        </div>

        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <table
            className="data-table"
            role="table"
            aria-label="Histórico de questionários"
          >
            <thead>
              <tr>
                <th scope="col">Questionário</th>
                <th scope="col">Data de conclusão</th>
                <th scope="col">Status</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              {HISTORY_DATA.map((h, i) => (
                <tr
                  key={i}
                  className="data-row"
                  tabIndex={0}
                  aria-label={`${h.name}, concluído em ${h.date}`}
                  onClick={() => alert(`Abrindo: ${h.name}`)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ")
                      alert(`Abrindo: ${h.name}`);
                  }}
                >
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <ClockCounterClockwise size={15} color="var(--text-3)" weight="regular" />
                      {h.name}
                    </div>
                  </td>
                  <td>{h.date}</td>
                  <td>
                    <span className="badge badge-green">{h.status}</span>
                  </td>
                  <td style={{ textAlign: "right" }}>
                    <ArrowRight size={15} color="var(--text-3)" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}

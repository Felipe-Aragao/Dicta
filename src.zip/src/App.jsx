import { useState } from "react";
import { SignOut, ArrowLeft, Waveform } from "@phosphor-icons/react";

import { LoginScreen }      from "./components/LoginScreen";
import { ProfessorScreen }  from "./components/ProfessorScreen";
import { UploadScreen }     from "./components/UploadScreen";
import { ExtractingScreen } from "./components/ExtractingScreen";
import { QuestionScreen }   from "./components/QuestionScreen";
import { DoneScreen }       from "./components/DoneScreen";
import { HistoryScreen }    from "./components/HistoryScreen";

import { useSpeech } from "./hooks/useSpeech";
import { useToast }  from "./hooks/useToast";

import { DEMO_QUESTIONS } from "./data/demoData";
import "./App.css";

export default function App() {
  const [role, setRole]       = useState(null);
  const [page, setPage]       = useState("login");
  const [answers, setAnswers] = useState([]);

  const { stopSpeak }               = useSpeech();
  const { toasts, show: showToast } = useToast();

  const navigate = (destino) => { stopSpeak(); setPage(destino); };

  const handleLogin = (papel) => {
    setRole(papel);
    navigate(papel === "professor" ? "professor-home" : "upload");
  };

  const handleLogout = () => {
    stopSpeak();
    setRole(null);
    setAnswers([]);
    setPage("login");
  };

  const handleStart    = () => { navigate("extracting"); setTimeout(() => navigate("question"), 2300); };
  const handleComplete = (res) => { setAnswers(res); navigate("done"); };
  const handleGenerate = () => { showToast("PDF gerado com sucesso!"); setTimeout(() => navigate("upload"), 2600); };

  // ── Topbar ─────────────────────────────────────────────────────
  const renderTopbar = () => {
    if (page === "login") {
      return (
        <header className="topbar" role="banner">
        <div className="logo">
        <div className="logo-mark" aria-hidden="true">
        <Waveform size={15} weight="bold" color="white" />
        </div>
        ***
        </div>
        </header>
      );
    }

    if (role === "professor") {
      return (
        <header className="topbar" role="banner">
        <div className="topbar-area">
        <button
        className="topbar-back-btn"
        onClick={handleLogout}
        aria-label="Voltar para o login"
        >
        <ArrowLeft size={17} weight="regular" />
        </button>
        <div className="topbar-divider" aria-hidden="true" />
        <span className="topbar-area-label">Área do Professor</span>
        </div>
        <button
        className="nav-btn"
        onClick={handleLogout}
        aria-label="Sair"
        >
        <SignOut size={16} weight="regular" />
        Sair
        </button>
        </header>
      );
    }

    // Aluno
    return (
      <header className="topbar" role="banner">
      <div className="logo">
      <div className="logo-mark" aria-hidden="true">
      <Waveform size={15} weight="bold" color="white" />
      </div>
      ***
      </div>
      <nav className="nav-btns" aria-label="Navegação">
      <button
      className={`nav-btn${page !== "history" ? " active" : ""}`}
      onClick={() => navigate("upload")}
      aria-label="Início"
      >
      Início
      </button>
      <button
      className={`nav-btn${page === "history" ? " active" : ""}`}
      onClick={() => navigate("history")}
      aria-label="Histórico"
      >
      Histórico
      </button>
      <div className="topbar-divider" aria-hidden="true" style={{ margin: "0 6px" }} />
      <button
      className="nav-btn"
      onClick={handleLogout}
      aria-label="Sair"
      >
      <SignOut size={16} weight="regular" />
      Sair
      </button>
      </nav>
      </header>
    );
  };

  return (
    <div className="vq-shell">
    {renderTopbar()}

    {page === "login"          && <LoginScreen onSelect={handleLogin} />}
    {page === "professor-home" && role === "professor" && <ProfessorScreen />}
    {page === "upload"         && role === "aluno" && <UploadScreen onStart={handleStart} />}
    {page === "extracting"     && role === "aluno" && <ExtractingScreen />}
    {page === "question"       && role === "aluno" && (
      <QuestionScreen questions={DEMO_QUESTIONS} onComplete={handleComplete} />
    )}
    {page === "done"           && role === "aluno" && (
      <DoneScreen
      onEdit={()     => navigate("question")}
      onGenerate={handleGenerate}
      onHome={()     => navigate("upload")}
      />
    )}
    {page === "history"        && role === "aluno" && <HistoryScreen />}

    {toasts.length > 0 && (
      <div className="toast-wrap" role="alert" aria-live="assertive">
      {toasts.map((t) => (
        <div key={t.id} className="toast">{t.msg}</div>
      ))}
      </div>
    )}
    </div>
  );
}
